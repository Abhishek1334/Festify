import Ticket from "../models/ticketModel.js";
import Event from "../models/eventModel.js";
import { generateQRCode } from "../utils/qrCodeGenerator.js";

// 🎟️ Book a Ticket
export const bookTicket = async (req, res) => {
	try {
		const { eventId } = req.body;
		const userId = req.user.id;

		// Check if the event exists
		const event = await Event.findById(eventId);
		if (!event) {
			return res.status(404).json({ message: "Event not found" });
		}

		// Create ticket
		const newTicket = new Ticket({
			userId, // ✅ Corrected field name
			eventId, // ✅ Corrected field name
		});

		// Generate QR Code for the ticket
		newTicket.qrCode = await generateQRCode(newTicket._id.toString());

		// Save the ticket
		await newTicket.save();

		res.status(201).json({
			message: "Ticket booked successfully",
			ticket: newTicket,
		});
	} catch (error) {
		console.error("Error booking ticket:", error);
		res.status(500).json({ message: "Internal server error" });
	}
};

// 🗂 Get User's Tickets
export const getUserTickets = async (req, res) => {
	try {
		const userId = req.user.id;
		console.log("User ID:", userId); // Debugging line
		const tickets = await Ticket.find({ userId }).populate(
			"eventId",
			"name date"
		);

		res.status(200).json(tickets);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Server error" });
	}
};

// 🎟 Get All Tickets for a Specific Event
export const getEventTickets = async (req, res) => {
	try {
		const { eventId } = req.params;

		// Check if the event exists
		const event = await Event.findById(eventId);
		if (!event) {
			return res.status(404).json({ message: "Event not found" });
		}

		// Get all tickets for the event
		const tickets = await Ticket.find({ eventId }).populate(
			"userId",
			"name email"
		);

		res.status(200).json(tickets);
	} catch (error) {
		console.error(error);
		res.status(500).json({ message: "Server error" });
	}
};

// ✅ Check-In a Ticket
export const checkInTicket = async (req, res) => {
	try {
		const { ticketId } = req.body;

		// Find the ticket by ID
		const ticket = await Ticket.findById(ticketId);
		if (!ticket) {
			return res.status(404).json({ message: "Ticket not found" });
		}

		// Check if already checked in
		if (ticket.checkedIn) {
			return res
				.status(400)
				.json({ message: "Ticket already checked in" });
		}

		// Mark ticket as checked in
		ticket.checkedIn = true;
		await ticket.save();

		res.status(200).json({ message: "Check-in successful", ticket });
	} catch (error) {
		console.error("Error during check-in:", error);
		res.status(500).json({ message: "Internal server error" });
	}
};

// Cancel a Ticket
export const cancelTicket = async (req, res) => {
	try {
		const { ticketId } = req.params;
		const userId = req.user.id; // Get user ID from the authentication middleware

		// Find the ticket
		const ticket = await Ticket.findById(ticketId);

		// Check if ticket exists
		if (!ticket) {
			return res.status(404).json({ message: "Ticket not found" });
		}

		// Ensure the ticket belongs to the logged-in user
		if (ticket.userId.toString() !== userId) {
			return res.status(403).json({ message: "Unauthorized to cancel this ticket" });
		}

		// Delete the ticket
		await Ticket.findByIdAndDelete(ticketId);

		res.status(200).json({ message: "Ticket canceled successfully" });
	} catch (error) {
		console.error("Error canceling ticket:", error);
		res.status(500).json({ message: "Internal server error" });
	}
};
