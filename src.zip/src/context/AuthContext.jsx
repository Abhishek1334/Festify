import { createContext, useState, useEffect, useContext } from "react";
import axios from "axios";
import { PropTypes } from "prop-types";
import { useNavigate } from "react-router-dom";

export const AuthContext = createContext();

export const AuthProvider = ({ children }) => {
	const [user, setUser] = useState(null);
	const [tickets, setTickets] = useState([]); // ✅ Store user tickets
	const navigate = useNavigate();
	const API_URL = import.meta.env.VITE_API_URL;

	// Load user from localStorage when the app starts
	useEffect(() => {
		const storedUser = localStorage.getItem("user");
		if (storedUser) {
			setUser(JSON.parse(storedUser));
		}
	}, []);

	// ✅ Signup
	const signup = async (name, email, password) => {
		try {
			const res = await axios.post(`${API_URL}/auth/signup`, {
				name,
				email,
				password,
			});
			setUser(res.data);
			localStorage.setItem("user", JSON.stringify(res.data));
			return true;
		} catch (error) {
			console.error("Signup failed", error.response?.data);
			return false;
		}
	};

	// ✅ Login
	const login = async (email, password) => {
		try {
			const res = await axios.post(`${API_URL}/auth/login`, {
				email,
				password,
			});
			setUser(res.data);
			localStorage.setItem("user", JSON.stringify(res.data));
			return true;
		} catch (error) {
			console.error("Login failed", error.response?.data);
			return false;
		}
	};

	// ✅ Logout
	const logout = () => {
		setUser(null);
		setTickets([]); // ✅ Clear tickets on logout
		localStorage.removeItem("user");
		navigate("/");
	};

	// ✅ Fetch User Tickets (Fixed endpoint)
	const fetchTickets = async () => {
		if (!user?.token) return; // ✅ Prevent API call if no user
		try {
			const res = await axios.get(`${API_URL}/tickets/my-tickets`, {
				headers: { Authorization: `Bearer ${user.token}` },
			});
			setTickets(res.data);
		} catch (error) {
			console.error("Error fetching tickets:", error);
		}
	};

	// ✅ Book a Ticket
	const bookTicket = async (eventId) => {
		try {
			const res = await axios.post(
				`${API_URL}/tickets/book`,
				{ eventId },
				{ headers: { Authorization: `Bearer ${user.token}` } }
			);
			setTickets([...tickets, res.data.ticket]); // Update state
		} catch (error) {
			console.error("Error booking ticket:", error);
		}
	};

	// ✅ Cancel a Ticket
	const cancelTicket = async (ticketId) => {
		try {
			await axios.delete(`${API_URL}/tickets/cancel/${ticketId}`, {
				headers: { Authorization: `Bearer ${user.token}` },
			});
			setTickets(tickets.filter((t) => t._id !== ticketId)); // Remove from state
		} catch (error) {
			console.error("Error canceling ticket:", error);
		}
	};

	// Fetch tickets when user logs in
	useEffect(() => {
		if (user?.token) fetchTickets();
	}, [user?.token]);

	return (
		<AuthContext.Provider
			value={{
				user,
				setUser,
				tickets,
				signup,
				login,
				logout,
				bookTicket,
				cancelTicket,
			}}
		>
			{children}
		</AuthContext.Provider>
	);
};

// ✅ Custom hook for consuming AuthContext
export const useAuth = () => useContext(AuthContext);

AuthProvider.propTypes = {
	children: PropTypes.node.isRequired,
};
