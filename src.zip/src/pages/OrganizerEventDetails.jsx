import { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";

const OrganizerEventDetail = () => {
	const { user } = useContext(AuthContext);
	const { eventId } = useParams();
	const navigate = useNavigate();

	const [event, setEvent] = useState(null);
	const [tickets, setTickets] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [isEditing, setIsEditing] = useState(false);
	const [editEvent, setEditEvent] = useState(null);
	const [imageFile, setImageFile] = useState(null);

	useEffect(() => {
		const fetchEventDetails = async () => {
			try {
				setLoading(true);
				const { data: eventData } = await axios.get(
					`http://localhost:5000/api/events/${eventId}`,
					{ headers: { Authorization: `Bearer ${user.token}` } }
				);
				setEvent(eventData);
				console.log(eventData)
				const { data: ticketData } = await axios.get(
					`http://localhost:5000/api/tickets/event/${eventId}`,
					{ headers: { Authorization: `Bearer ${user.token}` } }
				);
				setTickets(ticketData || []);
			} catch (err) {
				setError(err.response?.data?.message || "An error occurred");
			} finally {
				setLoading(false);
			}
		};

		if (eventId && user) {
			fetchEventDetails();
		}
	}, [eventId, user]);

	// Convert ISO time to 12-hour format
	const formatTime12Hour = (isoString) => {
		if (!isoString) return "N/A";

		const date = new Date(isoString);
		let hours = date.getHours();
		const minutes = date.getMinutes();
		const ampm = hours >= 12 ? "PM" : "AM";

		hours = hours % 12 || 12; // Convert 24-hour to 12-hour format

		return `${hours}:${minutes.toString().padStart(2, "0")} ${ampm}`;
	};

	// Extract HH:MM from ISO for form inputs
	const formatTime24Hour = (isoString) => {
		if (!isoString) return "";
		const date = new Date(isoString);
		const hours = date.getHours().toString().padStart(2, "0");
		const minutes = date.getMinutes().toString().padStart(2, "0");
		return `${hours}:${minutes}`;
	};

	// Handle Edit Click
	const handleEditClick = () => {
		setEditEvent({
			...event,
			startTime: event.startTime ? formatTime24Hour(event.startTime) : "",
			endTime: event.endTime ? formatTime24Hour(event.endTime) : "",
		});
		setIsEditing(true);
	};

	// Handle Input Changes
	const handleChange = (e) => {
		const { name, value } = e.target;
		setEditEvent((prev) => ({ ...prev, [name]: value }));
	};

	// Handle Image Change
	const handleImageChange = (e) => {
		setImageFile(e.target.files[0]);
	};

	// Handle Save Changes
	const handleSave = async () => {
		try {
			const formData = new FormData();
			Object.keys(editEvent).forEach((key) => {
				formData.append(key, editEvent[key]);
			});
			if (imageFile) {
				formData.append("image", imageFile);
			}
			
			const { data } = await axios.put(
				`http://localhost:5000/api/events/${eventId}`,
				formData,
				{
					headers: {
						Authorization: `Bearer ${user.token}`,
						"Content-Type": "multipart/form-data",
					},
				}
			);
			setEvent(data);
			console.log(data)
			setIsEditing(false);
		} catch (err) {
			console.error("Update failed:", err);
		}
	};

	if (loading) return <p className="text-center text-gray-500">Loading...</p>;
	if (error)
		return <p className="text-center text-red-500">Error: {error}</p>;
	if (!event)
		return <p className="text-center text-gray-500">Event not found.</p>;

	return (
		<div className="max-w-4xl mx-auto py-10 px-5">
			<button
				onClick={() => navigate("/organizer")}
				className="btn-primary mb-4 mr-5"
			>
				⬅ Back to Organizer Page
			</button>

			<button onClick={handleEditClick} className="btn-primary">
				Edit Event
			</button>

			{/* Event Image */}
			{event.image && (
				<img
					src={`http://localhost:5000/${event.image}`}
					alt={event.title}
					className="w-full h-64 object-cover rounded-lg mb-4"
				/>
			)}

			{/* Event Details */}
			<h1 className="text-3xl font-bold mb-2">{event.title}</h1>
			<p className="text-gray-600 mb-4">{event.description}</p>

			<div className="grid grid-cols-2 gap-4 mb-6">
				<div>
					<p className="text-lg font-semibold">📅 Date:</p>
					<p className="text-gray-700">{event.date?.split("T")[0]}</p>
				</div>
				<div>
					<p className="text-lg font-semibold">📍 Location:</p>
					<p className="text-gray-700">{event.location || "N/A"}</p>
				</div>
				<div>
					<p className="text-lg font-semibold">🕒 Start Time:</p>
					<p className="text-gray-700">
						{formatTime12Hour(event.startTime)}
					</p>
				</div>
				<div>
					<p className="text-lg font-semibold">⏳ End Time:</p>
					<p className="text-gray-700">
						{formatTime12Hour(event.endTime)}
					</p>
				</div>
				<div>
					<p className="text-lg font-semibold">📂 Category:</p>
					<p className="text-gray-700">{event.category || "N/A"}</p>
				</div>
			</div>

			{/* Edit Event Modal */}
			{isEditing && (
				<div className="fixed inset-0 flex items-center justify-center bg-gray-500 bg-opacity-50">
					<div className="bg-white p-6 rounded-lg w-96">
						<h2 className="text-xl font-bold mb-4">Edit Event</h2>

						<input
							name="title"
							value={editEvent.title}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
							placeholder="Title"
						/>
						<textarea
							name="description"
							value={editEvent.description}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
							placeholder="Description"
						></textarea>
						<input
							name="date"
							type="date"
							value={editEvent.date?.split("T")[0]}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
						/>
						<input
							name="startTime"
							type="time"
							value={editEvent.startTime || ""}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
						/>
						<input
							name="endTime"
							type="time"
							value={editEvent.endTime || ""}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
						/>
						{/* New Editable Fields */}
						<input
							name="location"
							value={editEvent.location || ""}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
							placeholder="Location"
						/>
						<input
							name="capacity"
							type="number"
							value={editEvent.capacity || ""}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
							placeholder="Capacity"
						/>
						<input
							name="category"
							value={editEvent.category || ""}
							onChange={handleChange}
							className="w-full mb-3 p-2 border rounded"
							placeholder="Category"
						/>
						<input
							type="file"
							name="image"
							className="w-full mb-3 p-2 border rounded"
							onChange={handleImageChange}
						/>

						<div className="flex justify-end space-x-2">
							<button
								onClick={() => setIsEditing(false)}
								className="btn-secondary"
							>
								Cancel
							</button>
							<button
								onClick={handleSave}
								className="btn-primary"
							>
								Save
							</button>
						</div>
					</div>
				</div>
			)}

			{/* Attendee Table */}
			<h2 className="text-2xl font-bold mb-4">🎟️ Attendees</h2>
			{tickets.length > 0 ? (
				<table className="w-full border-collapse border border-gray-300">
					<thead>
						<tr className="bg-gray-100">
							<th className="border border-gray-300 px-4 py-2">
								Name
							</th>
							<th className="border border-gray-300 px-4 py-2">
								Ticket ID
							</th>
							<th className="border border-gray-300 px-4 py-2">
								QR Code
							</th>
						</tr>
					</thead>
					<tbody>
						{tickets.map((ticket) => (
							<tr key={ticket._id} className="text-center">
								<td className="border px-4 py-2">
									{ticket.userName}
								</td>
								<td className="border px-4 py-2">
									{ticket._id}
								</td>
								<td className="border px-4 py-2">
									<img
										src={ticket.qrCode}
										alt="QR Code"
										className="w-20 h-20 mx-auto"
									/>
								</td>
							</tr>
						))}
					</tbody>
				</table>
			) : (
				<p className="text-gray-500">No attendees yet.</p>
			)}
		</div>
	);
};

export default OrganizerEventDetail;
