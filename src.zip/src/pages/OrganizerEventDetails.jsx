import { useEffect, useState, useContext } from "react";
import { useParams, useNavigate } from "react-router-dom";
import axios from "axios";
import { AuthContext } from "../context/AuthContext";
import categories from "../categories.json";

const OrganizerEventDetail = () => {
	const { user } = useContext(AuthContext);
	const { eventId } = useParams();
	const navigate = useNavigate();

	const [event, setEvent] = useState(null);
	const [tickets, setTickets] = useState([]);
	const [loading, setLoading] = useState(true);
	const [error, setError] = useState(null);
	const [isEditing, setIsEditing] = useState(false);
	const [formData, setFormData] = useState({});
	const [imagePreview, setImagePreview] = useState(null);

	useEffect(() => {
		const fetchEventDetails = async () => {
			try {
				const response = await axios.get(
					`http://localhost:5000/api/events/${eventId}`,
					{ headers: { Authorization: `Bearer ${user.token}` } }
				);
				setEvent(response.data);
				setFormData(response.data);
				setImagePreview(`http://localhost:5000/${response.data.image}`);
			} catch (err) {
				setError(err.message);
			}
		};

		const fetchTickets = async () => {
			try {
				const response = await axios.get(
					`http://localhost:5000/api/tickets/event/${eventId}`,
					{ headers: { Authorization: `Bearer ${user.token}` } }
				);
				setTickets(response.data);
			} catch (err) {
				setError(err.message);
			}
		};

		if (eventId && user) {
			Promise.all([fetchEventDetails(), fetchTickets()]).finally(() =>
				setLoading(false)
			);
		}
	}, [eventId, user]);

	// Handle input changes
	const handleChange = (e) => {
		setFormData({ ...formData, [e.target.name]: e.target.value });
	};

	// Handle event update
	const handleSave = async () => {
		try {
			const updatedEvent = { ...formData };
			console.log("Sending to backend:", updatedEvent); // Debugging log

			const response = await axios.put(
				`http://localhost:5000/api/events/${eventId}`,
				updatedEvent,
				{ headers: { Authorization: `Bearer ${user.token}` } }
			);

			setEvent(response.data);
			setIsEditing(false);
		} catch (error) {
			console.error("Error updating event:", error);
		}
	};


	// Handle loading state
	if (loading) return <p className="text-center text-gray-500">Loading...</p>;

	// Handle error state
	if (error)
		return <p className="text-center text-red-500">Error: {error}</p>;

	// Handle case when event data is missing
	if (!event)
		return <p className="text-center text-gray-500">Event not found.</p>;

	return (
		<div className="max-w-4xl mx-auto py-10 px-5">
			{/* Back Button */}
			<button
				onClick={() => navigate("/organizer")}
				className="mb-4 px-4 py-2 bg-gray-500 text-white rounded-lg hover:bg-gray-600"
			>
				⬅ Back to Organizer Page
			</button>

			{/* Event Image */}
			<img
				src={imagePreview || "/default-placeholder.jpg"}
				alt={event.title}
				className="w-full h-64 object-cover rounded-lg mb-4"
			/>

			{/* Editing Mode */}
			{isEditing ? (
				<div className="space-y-4">
					{/* Event Title */}
					<input
						type="text"
						name="title"
						value={formData.title}
						onChange={handleChange}
						className="text-3xl font-bold w-full p-2 border border-gray-300 rounded"
					/>

					{/* Event Category */}
					<select
						name="category"
						value={formData.category}
						onChange={handleChange}
						className="w-full p-2 mb-2 border rounded"
					>
						<option value="">No Category</option>
						{categories.map((cat) => (
							<option key={cat.category} value={cat.category}>
								{cat.name}
							</option>
						))}
					</select>

					{/* Event Date */}
					<input
						type="date"
						name="date"
						value={formData.date?.split("T")[0] || ""}
						onChange={handleChange}
						className="border border-gray-300 p-2 rounded w-full"
					/>

					{/* Event Timing */}
					<input
						type="time"
						name="timing"
						value={formData.timing || ""}
						onChange={handleChange}
						className="border border-gray-300 p-2 rounded w-full"
					/>

					{/* Event Capacity */}
					<input
						type="number"
						name="capacity"
						value={formData.capacity || ""}
						onChange={handleChange}
						className="border border-gray-300 p-2 rounded w-full"
					/>

					{/* Event Description */}
					<textarea
						name="description"
						value={formData.description}
						onChange={handleChange}
						className="border border-gray-300 w-full p-2 rounded"
					/>

					{/* Save Button */}
					<button
						onClick={handleSave}
						className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600"
					>
						Save Changes
					</button>
				</div>
			) : (
				<>
					<h2 className="text-3xl font-bold">{event.title}</h2>
					<p className="text-gray-700">{event.description}</p>
					<p className="text-gray-600 mt-2">
						<strong>Category:</strong> {event.category} |{" "}
						<strong>Date:</strong>{" "}
						{new Date(event.date).toLocaleDateString()} |{" "}
						<strong>Time:</strong> {event.timing} |{" "}
						{/* ✅ Use event.timing */}
						<strong>Location:</strong> {event.location}
					</p>

					<p className="text-gray-600">
						<strong>Capacity:</strong> {event.capacity} |{" "}
						<strong>Booked:</strong> {tickets.length}
					</p>

					{/* Edit Button */}
					<button
						onClick={() => setIsEditing(true)}
						className="mt-4 px-4 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600"
					>
						Edit Event
					</button>
				</>
			)}
		</div>
	);
};

export default OrganizerEventDetail;
