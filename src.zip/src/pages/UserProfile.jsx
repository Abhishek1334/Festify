import { useContext, useEffect, useState } from "react";
import { AuthContext } from "../context/AuthContext";
import EventCard from "../components/EventCard"; // Import EventCard
import { Link } from "react-router-dom";

const UserProfile = () => {
	const { user } = useContext(AuthContext);
	const [myEvents, setMyEvents] = useState([]);
	const [rsvpEvents, setRsvpEvents] = useState([]);
	const [activeTab, setActiveTab] = useState("myEvents"); // Manage tabs

	useEffect(() => {
		const fetchUserEvents = async () => {
			if (!user) return;

			try {
				const response = await fetch(
					"http://localhost:5000/api/events/my-events",
					{
						method: "GET",
						headers: {
							"Content-Type": "application/json",
							Authorization: `Bearer ${user.token}`,
						},
					}
				);

				if (!response.ok) {
					throw new Error("Failed to fetch events");
				}

				const data = await response.json();
				setMyEvents(data);
			} catch (error) {
				console.error("Error fetching user events:", error);
			}
		};

		const fetchRSVPEvents = async () => {
			if (!user) return;

			try {
				const response = await fetch(
					"http://localhost:5000/api/events/rsvp-events",
					{
						method: "GET",
						headers: {
							"Content-Type": "application/json",
							Authorization: `Bearer ${user.token}`,
						},
					}
				);

				if (!response.ok) {
					throw new Error("Failed to fetch RSVP events");
				}

				const data = await response.json();
				setRsvpEvents(data);
			} catch (error) {
				console.error("Error fetching RSVP events:", error);
			}
		};

		fetchUserEvents();
		fetchRSVPEvents();
	}, [user]);

	return (
		<div className="max-w-7xl mx-auto py-10 px-5">
			<h2 className="text-3xl font-bold mb-4">User Profile</h2>

			{/* User Details */}
			<div className="flex justify-between bg-white shadow-md rounded-lg p-6">
				<div>
					<p className="text-lg">
					<strong>Username:</strong> {user?.name || "Guest"}
				</p>
				<p className="text-lg">
					<strong>Email:</strong> {user?.email || "N/A"}
				</p>
				</div>
				<div>
					<Link to="/organizer" >
					<button className="btn-secondary">Organizer Panel</button>
					</Link>
				</div>
			</div>

			{/* Tab Navigation */}
			<div className="flex gap-10 mt-4 justify-center">
				<h3
					className={`text-2xl font-semibold mt-6 cursor-pointer ${
						activeTab === "myEvents"
							? "text-blue-600"
							: "text-gray-600"
					}`}
					onClick={() => setActiveTab("myEvents")}
				>
					My Events
				</h3>
				<h3
					className={`text-2xl font-semibold mt-6 cursor-pointer ${
						activeTab === "rsvpEvents"
							? "text-blue-600"
							: "text-gray-600"
					}`}
					onClick={() => setActiveTab("rsvpEvents")}
				>
					RSVP Events
				</h3>
			</div>

			{/* Events List */}
			<div className="flex justify-center mt-4 mx-auto">
				{activeTab === "myEvents" && myEvents.length > 0 ? (
					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						{myEvents.map((event) => (
							<EventCard key={event._id} event={event} />
						))}
					</div>
				) : activeTab === "rsvpEvents" && rsvpEvents.length > 0 ? (
					<div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
						{rsvpEvents.map((event) => (
							<EventCard key={event._id} event={event} />
						))}
					</div>
				) : (
					<p>No events found</p>
				)}
			</div>
		</div>
	);
};

export default UserProfile;
